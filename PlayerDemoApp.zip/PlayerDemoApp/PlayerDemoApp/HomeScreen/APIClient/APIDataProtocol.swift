//
//  APIDataProtocol.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


protocol APIDataProtocol {
    var subPathString: String { get }
    var headerParams: [String: Any]?  { get }
    var isURLEncrypted: Bool { get }
    func params() -> [String: Any]?
}

extension APIDataProtocol {
    func params()-> [String: Any]? {
        return [:]
    }
}

