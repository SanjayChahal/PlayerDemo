//
//  PlayListViewController.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import UIKit

class PlayListViewController: UIViewController {
    
    var viewModel: PlayListViewModel!
    

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.bindViewModel()
        
    }
    
    func configureTable() {
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "SongTableCell", bundle: nil), forCellReuseIdentifier: SongTableCell.identofire)
    }
    
    func bindViewModel() {
        self.viewModel = PlayListViewModel(interector: Interector.share)
        let colosure: (() -> ()) = {
            
            // Call table refresh on API success
            DispatchQueue.main.async { [ weak self] in
                guard let self = self else { return }
                self.tableView.reloadData()
            }
        }
        self.viewModel.closure = colosure
        self.viewModel.getSongsList()
    }
    
    
    
}

extension PlayListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.numberOfRow()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfSections()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SongTableCell.identofire, for: indexPath) as?  SongTableCell,
              let cellData = viewModel.songForCell(index: indexPath.row)
        else {
            return UITableViewCell()
        }
        
        cell.configureData(data: cellData)
        return cell
    }
    
}
