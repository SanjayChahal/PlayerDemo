//
//  Interector.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


final class Interector: InterectorProtocol {
    
     
    
    
    
    static let share: Interector = Interector()
    private var session: URLSession?
    private  init() {}
    
    func callAPI<T>(_ apiData: APIDataProtocol, _ dataModel: T, completionHandler: @escaping (Result<T, NetworkError>) -> Void) where T : Decodable {
        
        let configuration = URLSessionConfiguration.default
        self.session = URLSession(configuration: configuration)
        
        guard let url = URL(string: NetworkUtil.baseUrl + apiData.subPathString)
               else {
            completionHandler(.failure(NetworkError.urlError))
            return
        }
        
        let urlrequest = URLRequest(url: url)
        
        self.session?.dataTask(with: urlrequest, completionHandler: { data, response, error in
            
            if error != nil {
                // write func for error code
                completionHandler(.failure(NetworkError.responseError(errorCode: 040, error: error!)))
            }
            
            
            if let data = data {
                
                // write logic for parsing response into dataModel 
                
                
                //completionHandler(.success(<#T##Encodable#>))
                
            }
            
        }).resume()
        
        
    }
    
    
}
