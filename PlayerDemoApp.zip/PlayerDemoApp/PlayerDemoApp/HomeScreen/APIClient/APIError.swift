//
//  APIError.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


enum NetworkError: Error {
    case paramsError
    case parsingError
    case urlError
    case responseError(errorCode: Int, error: Error)
    // All generic cases
}
