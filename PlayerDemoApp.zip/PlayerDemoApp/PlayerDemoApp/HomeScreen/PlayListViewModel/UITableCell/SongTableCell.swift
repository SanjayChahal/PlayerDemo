//
//  SongTableCell.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import UIKit

protocol SongCellDataProtocol {
    var title: String { get }
    var artist: String { get }
    var album: String { get }
    var duration: Double { get }
}

class SongTableCell: UITableViewCell {

    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var albumLabel: UILabel!
    @IBOutlet weak var titleLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureData(data: SongCellDataProtocol) {
        self.titleLable.text =  data.title
    }
    
}

extension SongTableCell {
    static let identofire = "SongTableCellIdentifire"
}
