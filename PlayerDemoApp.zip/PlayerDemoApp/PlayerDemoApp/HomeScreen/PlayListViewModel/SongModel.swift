//
//  Audio.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


struct SongModel: Decodable, SongCellDataProtocol {
    let title: String
    let artist: String
    let album: String
    let duration: Double
}

