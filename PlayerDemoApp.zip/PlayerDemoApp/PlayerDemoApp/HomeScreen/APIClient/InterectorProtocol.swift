//
//  InterectorProtocol.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


protocol InterectorProtocol {
    func callAPI<T: Decodable>(_ apiData: APIDataProtocol, _ dataModel: T,  completionHandler: @escaping (Result<T, NetworkError>) -> Void)
}
