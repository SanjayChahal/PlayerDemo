//
//  PlayListAPIData.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation



struct PlayListAPIData: APIDataProtocol {
    var headerParams: [String : Any]?
    
    private let numberOfSongs: Int
    let subPathString: String = "v3/9c2f52ae-51bc-4c79-a4d3-ef12971a7464"
    var isURLEncrypted: Bool = true
    
    init(numberOfSongs: Int) {
        self.numberOfSongs = numberOfSongs
    }
    
    func params() -> [String : Any]? {
        return ["song_count":self.numberOfSongs]
    }
    
}
