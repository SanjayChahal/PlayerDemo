//
//  NetWorkUtility.swift
//  PlayerDemoApp
//
//  Created by Sanjay Chahal on 03/10/23.
//

import Foundation


final class NetworkUtil {
    static let baseUrl = "https://run.mocky.io/"
}
